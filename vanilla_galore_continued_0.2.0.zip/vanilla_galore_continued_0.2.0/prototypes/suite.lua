-- suite mode

-- if settings.startup["vgal-suite-mode"].value then
--     data.raw["furnace"]["electric-furnace"].crafting_speed = 4
--     data.raw["mining-drill"]["electric-mining-drill"].mining_speed = 2
--     data.raw["electric-pole"]["medium-electric-pole"].supply_area_distance = 4.5
--     data.raw["electric-pole"]["substation"].supply_area_distance = 10
-- end
